const express = require("express"),
	  Campground = require("../models/campground"),
	  router = express.Router();

//index route
router.get("/", function(req,res){
	Campground.find({})
	.then((allCampgrounds) => res.render("campgrounds/index", {campgrounds:allCampgrounds}))
	.catch(err=>console.log(err));
});

//create route 

router.post("/", isLoggedIn,function(req,res){
	Campground.create({
	name: req.body.name, 
	image: req.body.image,
	description: req.body.description,
	author: {
		id: req.user._id,
		username: req.user.username
	}
	})
	.then((campground) => {
		res.redirect("/campgrounds");
	})
	.catch (err => console.log(err));
});

//new route 

router.get("/new", isLoggedIn,function(req,res){
	res.render("campgrounds/new")
});

//show route

router.get("/:id", function(req,res){
	Campground.findById(req.params.id).populate("comments").exec()
	.then((foundCampground) => res.render("campgrounds/show", {campground: foundCampground}))
	.catch((err) => console.log(err));
});

//edit
router.get("/:id/edit", function(req,res){
	Campground.findById(req.params.id)
	.then((foundCampground) => {
		res.render("campgrounds/edit", {campground: foundCampground});
	})
	.catch((err)=>console.log(err));
});

//update
router.put("/:id", function(req,res){
	Campground.findByIdAndUpdate(req.params.id, req.body.campground)
	.then((updatedCampground) => {
		res.redirect("/campgrounds/" + req.params.id);
	})
	.catch((err) => console.log(err));
});

//destroy
router.delete("/:id", function(req,res){
	Campground.findByIdAndRemove(req.params.id)
	.then(() => res.redirect("/campgrounds"))
	.catch((err) => console.log(err));
})

function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	res.redirect("/login");
}

module.exports = router;