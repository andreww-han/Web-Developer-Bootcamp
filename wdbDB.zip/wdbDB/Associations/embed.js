const mongoose = require("mongoose");

mongoose.connect('mongodb://localhost:27017/blog_demo', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
	useFindAndModify: false
})
.then(() => console.log('Connected to DB!'))
.catch(error => console.log(error.message));


//Post - title, content
const postSchema = new mongoose.Schema({
	title: String,
	content: String
});
const Post = mongoose.model("Post", postSchema);

//User - email, name
const userSchema = new mongoose.Schema({
	email: String,
	name: String,
	posts: [postSchema]
});
const User = mongoose.model("User", userSchema);


// const newUser = new User({
// 	email: "hermione@hogwarts.edu",
// 	name: "Hermione Granger"
// });

// // newUser.posts.push({
// // 	title: "How to brew polyjuice potions",
// // 	content: "Just kidding. Go to potions class to learn it."
// // });

// newUser.save()
// .then((user)=> console.log(user))
// .catch((err)=> console.log(err));

User.findOne({name: "Hermione Granger"})
.then((user)=>{
	user.posts.push({
		title: "3 things I really hate",
		content: "Voldemort Voldemort Voldemort"
	});
	user.save()
	.then((user)=> console.log(user))
	.catch((err)=> console.log(err));
})
.catch((err)=>console.log(err));

// const newPost = new Post({
// 	title: "Reflections on Apples",
// 	content: "They are delicious"
// });

// newPost.save()
// .then((post)=> console.log(post))
// .catch((err)=> console.log(err));