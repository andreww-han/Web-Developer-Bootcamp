const mongoose = require("mongoose");
const Post = require("./models/post")
const User = require("./models/user")

mongoose.connect('mongodb://localhost:27017/blog_demo2', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
	useFindAndModify: false
})
.then(() => console.log('Connected to DB!'))
.catch(error => console.log(error.message));


// User.create({
// 	email: "bob@gmail.com",
// 	name: "Bob Belcher"
// })

Post.create({
	title: "How to cook the best burger part 4",
	content: "keljowgkjrgwogjowhjorhwjohrj"
})
.then((post)=> {User.findOne({email:"bob@gmail.com"})
			   .then((foundUser)=> {foundUser.posts.push(post)
								   	foundUser.save()
								   .then((data)=> console.log(data))
								   .catch((err)=> console.log(err))})
			   .catch((err)=> console.log(err))})
.catch((err)=>console.log(err));

// User.findOne({email:"bob@gmail.com"}).populate("posts").exec()
// .then((user)=> console.log(user))
// .catch((err)=>console.log(err));










