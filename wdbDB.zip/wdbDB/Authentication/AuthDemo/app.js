const express 				= require("express"),
	  app 					= express(),
	  mongoose 				= require("mongoose"),
	  passport 				= require("passport"),
	  bodyParser			= require("body-parser"),
	  localStrategy 		= require("passport-local"),
	  passportLocalMongoose = require("passport-local-mongoose"),
	  User 					= require("./models/user");

mongoose.connect('mongodb://localhost:27017/auth_demo', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
	console.log('Connected to DB!')
})
.catch(error => console.log(error.message));

app.use(require("express-session")({
	secret:"Rusty is the best and cutest dog in the world.",
	resave: false,
	saveUninitialized: false
}));

app.set("view engine", "ejs");
app.use(passport.initialize());
app.use(passport.session());
app.use(bodyParser.urlencoded({extended:true}));

passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());
passport.use(new localStrategy(User.authenticate()));

app.get("/", function(req,res){
	res.render("home");
});

app.get("/secret",isLoggedIn,function(req,res){
	res.render("secret");
});

//Auth routes

//show register form
app.get("/register", function(req,res){
	res.render("register");
});

app.post("/register", function(req,res){
	req.body.username;
	req.body.password;
	User.register(new User({username: req.body.username}), req.body.password)
	.then((user) => {
		passport.authenticate("local")(req,res,function(){
			res.redirect("/secret");
		})
	})
	.catch((err) => console.log(err));
})

//login routes
//middleware
app.get("/login",function(req,res){
	res.render("login");	
});

app.post("/login", passport.authenticate("local", {
	successRedirect: "/secret",
	failureRedirect: "/login"
}),function(req,res){
});

//logout routes
app.get("/logout",function(req,res){
	req.logout();
	res.redirect("/")
});

function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	res.redirect("/login");
}

app.listen(3000, function(){
	console.log("Server started");
});