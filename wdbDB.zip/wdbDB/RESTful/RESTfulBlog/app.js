const express = require("express"),
	  app = express(),
	  bodyParser = require("body-parser"),
	  mongoose = require("mongoose"),
	  methodOverride = require("method-override"),
	  expressSanitizer = require("express-sanitizer");

mongoose.connect('mongodb://localhost:27017/restful_blog_app', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
	useFindAndModify: false
})
.then(() => console.log('Connected to DB!'))
.catch(error => console.log(error.message));

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));
app.use(methodOverride("_method"));
app.use(expressSanitizer());

const blogSchema = new mongoose.Schema({
	title: String,
	image: String,
	body: String,
	created: {type: Date, default: Date.now}
});

const Blog = mongoose.model("Blog",blogSchema);

// Blog.create({
// 	title:"Test",
// 	image:"https://s3.amazonaws.com/cdn-origin-etr.akc.org/wp-content/uploads/2017/11/14112506/Pembroke-Welsh-Corgi-standing-outdoors-in-the-fall.jpg",
// 	body:"This is a test"
// });

app.get("/",function(req,res){
	res.redirect("/blogs");
});

//index route
app.get("/blogs", function(req,res){
	Blog.find({})
	.then((blogs) => res.render("index", {blogs: blogs}))
	.catch(err => console.log(err));
});

//new route
app.get("/blogs/new", function(req,res){
	res.render("new");
})

//create route
app.post("/blogs",function(req,res){
	const newPost = req.body.blog;
	newPost.body = req.sanitize(newPost.body);
	Blog.create({
		title: newPost.title,
		image: newPost.image,
		body: newPost.body
	})
	.then((newBlog) => {
		console.log("New blog created");
		console.log(newBlog);
		res.redirect("/blogs");
	})
	.catch((err) => console.log(err));
});

//show route
app.get("/blogs/:id", function(req,res){
	Blog.findById(req.params.id)
	.then((id) => res.render("show", {blog:id}))
	.catch((err) => console.log(err));
})

//edit route
app.get("/blogs/:id/edit", function(req,res){
	Blog.findById(req.params.id)
	.then((foundBlog) => res.render("edit", {blog:foundBlog}))
	.catch((err) => console.log(err));
});

//update route
app.put("/blogs/:id", function(req,res){
	const newPost = req.body.blog;
	newPost.body = req.sanitize(newPost.body);
	Blog.findByIdAndUpdate(req.params.id, newPost)
	.then((updatedBlog) => res.redirect("/blogs/" + req.params.id))
	.catch((err)=> console.log(err));
});

//delete route
app.delete("/blogs/:id",function(req,res){
	Blog.findByIdAndRemove(req.params.id)
	.then(()=>res.redirect("/blogs"))
	.catch((err) => console.log(err))
});

app.listen(3000, function(){
	console.log("Server listening on port 3000");
})